////////////////////////////////

Giới thiệu bản mô phỏng phần mềm thi trắc nghiệm sQz
 của Trung tâm Ngoại ngữ - Tin học Long An.
 
////////////////////////////////

Đây là phiên bản chưa hoàn chỉnh,
 giao diện tương đối giống với phần mềm sQz,
 mục đích để tạo bài thực hành tiện lợi cho việc luyện tập.

////////////////////////////////

Cách sử dụng
	Mở file qz*.html bằng Internet Explorer hoặc Google Chrome
	(Firefox chưa hỗ trợ) và làm bài.

////////////////////////////////

Cách tạo bài thực hành mới

- Soạn file đề bài định dạng *.txt và đặt tên là "qz1.txt", "qz2.txt", ... theo thứ tự tăng dần.
- Trong file đề bài có nhiều câu hỏi, mỗi câu hỏi có đúng 4 lựa chọn, theo cấu trúc như sau
	+ Dòng đầu tiên là phát biểu
	+ 4 dòng tiếp theo là 4 lựa chọn
	+ Lựa chọn đúng có ký tự '\' ở đầu dòng
	+ Các câu hỏi cách nhau bởi một dòng trống
	Ví dụ:
	
	Thao tác chọn File -> Close dùng để
	Thoát khỏi Powerpoint
	Mở một tập tin nào đó
	\Đóng tập tin hiện tại
	Lưu tập tin hiện tại

	Người và máy tính giao tiếp với nhau thông qua
	Bàn phím
	\Hệ điều hành
	Đĩa cứng
	Chuột

- Để tạo file làm bài, đặt file đề bài *.txt vào cùng thư mục với file thực thi sQz_*.exe
	và chạy file thực thi để tạo ra file "qz1.html", "qz2.html", ... tương ứng.
	
	Nếu đang dùng Windows 7 thì máy phải có .NET Framework 4.5 trở lên.
	Nếu đang dùng Windows 8 thì chạy sQz_CS_net45_win8.exe.
	Nếu đang dùng Windows 10 thì chạy sQz_CS_net46_win10.exe.

	File thực thi sẽ đọc file đề bài *.txt, tạo file bài làm *.html tương ứng.

- File làm bài qz*.html cần đặt chung các files sQz.css, sQz.js mới hoạt động.

////////////////////////////////

Nếu chạy file sQz_CS_*.exe có lỗi thì sẽ nhận được thông báo tương tự như sau:

	sQz_CS 1.1.0.0
	Error in qz1.txt
	Check current questions in qz_error.txt

Khi đó, đóng cửa sổ lệnh lại và kiểm tra các câu hỏi trong qz_error.txt từ câu cuối cùng trở lên
 để phát hiện lỗi.

////////////////////////////////

Cách tạo bài thực hành mới (nâng cao)

(*) Chèn hình:
- Để gọn gàng, nên (không bắt buộc) gom hình ảnh vào một thư mục có tên là images.
- Chỗ nào muốn chèn hình thì đặt đường dẫn hình vào trong cặp dấu {}. Ví dụ:
	Hình {images\whatsThis.jpg} là thiết bị gì?

(*) Xuống dòng trong câu dẫn hay câu lựa chọn:
- Đặt dấu \ vào cuối dòng thì chương trình hiểu dòng tiếp theo gắn liền với dòng trước. Ví dụ:
	(Minh họa câu hỏi nhiều dòng) Muốn kết thúc đoạn văn,\
	 dùng phím hay\
	 tổ hợp phím nào?
	\Enter.
	(Minh họa câu trả lời nhiều dòng)Shift\
	 cùng với Enter.
	Shift.
	Caps Lock.

////////////////////////////////

Trung tâm Ngoại ngữ - Tin học Long An xin cám ơn sự quan tâm của quý thầy cô.
Địa chỉ email:
	daotao.nnthla@gmail.com
	training.lalgitc@outlook.com